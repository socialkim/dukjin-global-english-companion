# Dukjin Global — English Companion

Chrome MV3 side-panel extension for English subtitles and summaries on Kim Dukjin's Korean YouTube broadcasts.

## Run the working demo

1. Open `chrome://extensions` in Chrome 138 or newer.
2. Turn on **Developer mode**.
3. Choose **Load unpacked** and select this `extension` directory.
4. Open `https://www.youtube.com/watch?v=YTfathQEoXc`.
5. Click the extension icon. The side panel opens with a summary, seekable key points, chapters and transcript. The player displays the bundled English subtitle cues during the first three minutes.

The demo requires no account, API key or network service beyond YouTube. It never reads cookies or browsing history.

On other videos, turn on YouTube's Korean captions and choose **Start live on-device translation** in the side panel. Chrome downloads its private Korean → English language model after that user gesture, translates visible caption cues in a FIFO queue, and renders the result back over the player. This live path never uploads caption text.

## Production path

The bundled catalog is deliberately small. In production, replace `DEMO_CATALOG` in `background.js` with a read-only localization API for creator-owned videos. The response contract already separates video metadata, timed cues, English summary and provenance.

For creator-owned content, use YouTube OAuth on the backend to export captions, then pre-generate and review English cues. Chrome's Translator API can provide a private on-device fallback; it must run in the side panel rather than the MV3 service worker.

Do not make YouTube's undocumented timed-text endpoints the production dependency. Signed URLs expire and public bulk access is easily throttled.

## Privacy and permissions

- `storage`: remembers the current video context locally.
- `sidePanel`: provides a persistent companion next to YouTube.
- No `tabs`, `identity`, `webRequest`, `<all_urls>` or remote-code permission.
- Only the YouTube video ID and title are processed, and the demo sends nothing to a third-party service.

## Acceptance targets

- Subtitle sync error: under ±250 ms for reviewed cues.
- YouTube SPA route change recovery: under 1 second.
- Graceful no-catalog state: YouTube playback is never interrupted.
- Full keyboard navigation in the side panel.
